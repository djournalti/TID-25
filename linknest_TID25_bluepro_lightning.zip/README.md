# LinkNest Blue Pro — TID-25

Blue Pro edition with lightning favicon and live editor. Deploy to GitHub Pages by uploading all files and committing.