# 🌐 LinkNest — Linktree Clone (React + Vite + Tailwind)

## 🚀 Cara pakai
1. Clone repositori ini
2. Jalankan:
   ```bash
   npm install
   npm run dev
   ```
3. Edit profil & link lewat UI
4. `npm run build` untuk versi final

## ☁️ Deploy ke GitHub Pages
Sudah otomatis dengan GitHub Actions.
Cukup push ke branch `main`, dan halamanmu akan muncul di:

https://username.github.io/linknest/

Ubah nama repository di `vite.config.js` jika berbeda.
